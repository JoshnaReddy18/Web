
    function Displaytext(){
        document.getElementById("text1").innerHTML="Successfully implemented external javascript";
    }