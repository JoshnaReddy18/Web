let i=0;

function timedCount(){
    i++;
    postMessege(i);
    setTimeout("timedCount()",500);
}
timedCount();